#!/user/local/bin/perl

# set up to iterate over the 513 *.fasta files of Cuff and Barton's in the current directory,
# editing in place and saving the old file with a .orig extension
local $^I   = '.orig';              # emulate  -i.orig
local @ARGV = glob("*.sec");          # initialize list of files
while (<>) {

next if 3 .. eof;
print;

   
} continue {close ARGV if eof} 

