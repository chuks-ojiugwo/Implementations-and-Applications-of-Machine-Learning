#!/user/local/bin/perl

# set up to iterate over the *.fasta files in the current directory,
# editing in place and saving the old file with a .orig2 extension
local $^I   = '.orig2';              # emulate  -i.orig
local @ARGV = glob("*.sec");          # initialize list of files
while (<>) {

   # if ($. == 1) {
       
 #print "This line should appear at the top of each file\n";
 #  print "> \n";

  # }

  
  # s/^RES://g;  
   s/,/ /g; 
#    s/\s/ /g;
  
 
print;
} continue {close ARGV if eof} 

