
#!/usr/bin/perl
use strict;

foreach my $file (<*.txt>) {
  open FILE, $file or warn "Can not open $file $!\n";
  while (<FILE>) {
      # do something with the contents
  }
   close FILE;
}

----------------------------------------
#!/usr/bin/perl
# Read a fasta file and extract the sequence data

use strict;
use warnings;


opendir(DIR, ".");

my @filedata = grep(/.all$/, readdir(DIR));
#my @filedata = sort(grep(/.all$/, readdir(DIR)));
closedir(DIR);


foreach my $filename (@filedata) {
  #my $filename = $file;

# Initialize variables
    #my @filedata = (  );
#my $filename="9insb.all";

    unless( open(GET_FILE_DATA, "+< $filename") ) {
        print STDERR "Cannot open file \"$filename\"\n\n";
        exit;
    }

    @filedata = <GET_FILE_DATA>;
# change array here

my @sequence = grep(/^RES/ || /^DSSP/, @filedata );
   
 my $res= $sequence[0];
 my $dssp= $sequence[1];   
      
 
    # remove comma  from sequences string
     $res =~ s/,//g; #saad
    #$res =~ s/\s/ /g; # and whitespace
 

#dssp H and G to H,E and B to E, others to C 
$dssp =~ s/,//g; #saad
$dssp =~ s/_/C/g;
$dssp =~ s/T/C/g;
$dssp =~ s/S/C/g;
$dssp =~ s/G/H/g;
$dssp =~ s/B/E/g;

#$dssp =~ s/\s/ /g;
   


#@filedata =($res,$dssp);
@filedata =($res,);

#----------------------------------------------
seek(GET_FILE_DATA,0,0) or die "seeking $!";

print GET_FILE_DATA   @filedata or die "printing  $!";
truncate( GET_FILE_DATA, tell( GET_FILE_DATA) ) or die "truncating $!";

 close GET_FILE_DATA  or die " closeing $!";

 
}


rename_file( @filedata);
exit;

#---------------------
 sub rename_file {

#my ($file)= @_;
my @files=();

foreach my $file (@files) {
  my $newfile = $file;
  $newfile =~ s/^[0-9]/[z]/g;
  $newfile =~ s/-//g;
                                                          
  $newfile =~ s/\.all$/.fasta/;

  if (-e $newfile) {
    warn "can't rename $file to $newfile: $newfile exists\n";
  } elsif (rename $file, $newfile) {
    ## success, do nothing
  } else {
    warn "rename $file to $newfile failed: $!\n";
  }
} }
