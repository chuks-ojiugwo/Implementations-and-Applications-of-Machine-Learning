#!/user/local/bin/perl

# set up to iterate over the *.c files in the current directory,
# editing in place and saving the old file with a .orig extension
local $^I   = '.orig2';              # emulate  -i.orig
local @ARGV = glob("*.all");          # initialize list of files
while (<>) {

    if ($. == 1) {
       
 #print "This line should appear at the top of each file\n";
   print "> \n";

 }

   # s/\b(p)earl\b/${1}erl/ig;       # Correct typos, preserving case
   s/^RES://g;  
   s/,//g; 
   # s/\s/ /g;
  
 
print;
} continue {close ARGV if eof} 

