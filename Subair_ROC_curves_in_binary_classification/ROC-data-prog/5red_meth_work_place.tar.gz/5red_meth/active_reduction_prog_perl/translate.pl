#!/user/local/bin/perl

# set up to iterate over the *.fasta files in the current directory,
# editing in place and saving the old file with a .orig2 extension
local $^I   = '.orig3';              # emulate  -i.orig
local @ARGV = glob("*.sec");          # initialize list of files
while (<>) {

   

  
  s/^DSSP://g;  
   s/,/ /g; 
  
#dssp H and G to H,E and B to E, others to C 

 s/_/C/g;
 s/T/C/g;
 s/S/C/g;
 s/G/H/g;
 s/B/E/g;


#    s/\s/ /g;
  
 
print; # unless 1 .. 1;
} continue {close ARGV if eof} 

