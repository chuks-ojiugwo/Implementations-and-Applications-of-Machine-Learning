#!/usr/bin/perl
#  Demonstrate File::Find

use strict;
use warnings;
use BeginPerlBioinfo;     # see Chapter 6 about this module

use File::Find;

find ( \&my_sub, ('/home/saad/Experiment_Data/') );

sub my_sub {

my $str1='./Hybrid -c -v -d -m 0 -i ';
my $str2=' -b nr -o ';
my $str3='X';
print $str1;
    -f and (print  $File::Find::name);
print( $str2);
  -f and (print  $File::Find::name);
print ($str3, "\n");
}

exit;
