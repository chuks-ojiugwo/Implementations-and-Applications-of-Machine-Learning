#!/user/local/bin/perl

# This will increase sample to 480

local $^I   = '.orig3';              # emulate  -i.orig
local @ARGV = glob("*.sec");          # initialize list of files
while (<>) {

   

  
  s/^DSSP://g;  
   s/,/ /g; 
  
#dssp H and G to H,E and B to E, others to C 

 s/G/H/g;

 s/B/E/g;

 s/_/C/g;
 s/T/C/g;
 s/S/C/g;
 s/I/C/g;

 
print; 
} continue {close ARGV if eof} 

