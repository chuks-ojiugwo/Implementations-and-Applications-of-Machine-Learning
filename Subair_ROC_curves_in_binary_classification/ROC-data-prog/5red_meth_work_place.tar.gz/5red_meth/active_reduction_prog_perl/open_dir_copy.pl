#!/user/local/bin/perl

use File::Copy
opendir(DIR, ".");

my @files = sort(grep(/.fasta$/, readdir(DIR)));

closedir(DIR);


foreach my $file (@files) {
  my $newfile = $file;
  $newfile =~ s/\.fasta$/.ss/;
  if (-e $newfile) {
    warn "can't rename $file to $newfile: $newfile exists\n";
  } elsif (copy $file, $newfile) {
    ## success, do nothing
  } else {
    warn "rename $file to $newfile failed: $!\n";
  }
}
