#!/user/local/bin/perl

use strict;
use warnings;


opendir(DIR, ".");

my @files = sort(grep(/.all$/, readdir(DIR)));

closedir(DIR);


foreach my $file (@files) {
  my $newfile = $file;
  $newfile =~ s/^[0-9]/z/g;
  $newfile =~ s/-//g;
 $newfile =~ s/.1//g;
                                                          
  $newfile =~ s/\.all$/.sec/;

  if (-e $newfile) {
    warn "can't rename $file to $newfile: $newfile exists\n";
  } elsif (rename $file, $newfile) {
    ## success, do nothing
  } else {
    warn "rename $file to $newfile failed: $!\n";
  }
}



exit;
