#!/user/local/bin/perl

# set up to iterate over the *.fasta files in the current directory,
# editing in place and saving the old file with a .orig2 extension
local $^I   = '.orig2';              # emulate  -i.orig
local @ARGV = glob("*.sec");          # initialize list of files
while (<>) {

   
 
print unless 1 .. 1;
} continue {close ARGV if eof} 

