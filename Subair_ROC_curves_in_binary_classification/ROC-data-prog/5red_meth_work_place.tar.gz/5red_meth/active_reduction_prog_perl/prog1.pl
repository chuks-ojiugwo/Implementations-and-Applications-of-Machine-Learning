#!/user/local/bin/perl

# set up to iterate over the *.c files in the current directory,
# editing in place and saving the old file with a .orig extension
local $^I   = '.orig2';              # emulate  -i.orig
local @ARGV = glob("*.all");          # initialize list of files
while (<>) {

next if 2 .. eof;
print;

   
} continue {close ARGV if eof} 

