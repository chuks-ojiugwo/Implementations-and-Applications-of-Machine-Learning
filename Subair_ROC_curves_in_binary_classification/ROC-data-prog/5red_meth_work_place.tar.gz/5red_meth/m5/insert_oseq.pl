#!/user/local/bin/perl

# set up to iterate over the *.fasta files in the current directory,
# editing in place and saving the old file with a .orig2 extension
local $^I   = '.orig';              # emulate  -i.orig
local @ARGV = glob("*.sov");          # initialize list of files
while (<>) {

    if ($. == 1) {
       
 #print "This line should appear at the top of each file\n";

   print ">OSEQ \n";

 }

  
print;
} continue {close ARGV if eof} 

