#!/user/local/bin/perl

# set up to iterate over the *.fasta files in the current directory,
# editing in place and saving the old file with a .orig2 extension
local $^I   = '.orig2';              # emulate  -i.orig
local @ARGV = glob("*.sec");          # initialize list of files
while (<>) {

   

  
  s/^DSSP://g;  
   s/,/ /g; 
  
#dssp H to H,   E,B to E,     others to C  (I, G,_,S,T)


 # H to H;
 
 s/B/E/g;
 
 s/I/C/g;
 s/_/C/g;
 s/T/C/g;
 s/S/C/g;
 s/G/C/g; 



  
 
print; 
} continue {close ARGV if eof} 

