#!/user/local/bin/perl


local $^I   = '.orig2';              # emulate  -i.orig
local @ARGV = glob("*.sec");          # initialize list of files
while (<>) {

   

  
  s/^DSSP://g;  
   s/,/ /g; 
  
#dssp H,G, and I to H,   E to E,     others to C  (B,_,S,T)


 s/G/H/g;
 s/I/H/g;

# E to E

 s/_/C/g;
 s/T/C/g;
 s/S/C/g;
 s/B/C/g;
 



  
 
print; 
} continue {close ARGV if eof} 

