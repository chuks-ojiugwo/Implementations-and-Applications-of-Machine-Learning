
                                 merge README

   By: Jeremy Buchmann

   merge  is  a  Perl  script  that merges Netscape, Mozilla and Internet
   Explorer  bookmark  files.  Note  that only certain versions of IE use
   bookmark files.

Obtaining merge

   merge   is   hosted   on   [1]sourceforge.net.   The   Web   page   is
   [2]http://merge.sourceforge.net.

What merge Does

     * Merges Netscape 4.x, Mozilla/Netscape 6.x and IE bookmark files.

What merge Doesn't Do Now, But May Do Later

     * Check links for validity.
     * Merge Opera bookmarks.
     * Sort links
     * Remove duplicate links from different folders.

Usage

   > merge -m[NS,MO,IE] master-file -s[NS,MO,IE] slave-file

   Any combination of bookmark files is okay. The output type will be the
   same  as  the master type. Only URLs are compared; if they match, only
   the  master  copy is kept. The directory structure is kept intact. The
   resulting  bookmarkfile  is  printed  to  stdout,  so  you'll  want to
   redirect it to a file.

   For example:
   > merge -mNS bookmarks.html -sIE Favorites.html > newbookmarks.html
   would  merge  a  master  Netscape  file called "bookmarks.html" with a
   slave  IE  file  called  "Favorites.html" and write the merged file to
   "newbookmarks.html".

Change Log

  merge-0.9

     * Rewrote most of the internal structures, which means:
          + Adding new types of bookmark files should be much easier.
          + Link and folder meta-data is now mostly kept.
          + Separators should now work.
          + Crasher bugs related to huge bookmark files should go away.
     * Crasher bug caused by lack of bookmark name is fixed.

  merge-0.3

     * IE  bookmark  files  now  work! (for those versions of IE that use
       bookmark files instead of a directory structure).
     * Added the new command line stuff.
     * Pipe  symbols  '|'  are  now turned into '!' before processing the
       bookmark file.
     * The  output spacing is a little more accurate (the browser doesn't
       really care, but I do :).

  merge-0.2

     * Got rid of some dumb parentheses in parseLinks().
     * Added  better  URL  comparing  with the URL_equal() function. This
       should  fix  bug  #113467.  I  don't  think  [http://foo.com]  and
       [http://foo.com/index.html]  should  be the same anymore...PHP and
       other  dynamic  stuff has changed this. http://linuxtoday.com is a
       good example of this.
     * printTree()  now  uses  the  current time for all the time-related
       stuff in the links. This should take care of bug #113469.

  merge-0.1

     * First release

Bugs/Issues

     * [http://foo.com] will not match [http://foo.com/index.html] in any
       cases. This isn't a bug.
     * merge  may  not  preserve  all  attributes  of  a  bookmark  (like
       subscriptions  or  other really advanced stuff), but simple things
       like dates should be kept.
     * merge  is written in Perl, so you have to have a Perl interpreter.
       Perl  is  standard on most if not all UNIX-like operating systems,
       and there are Windows and Mac ports as well.
     * On  a  related  note, perl is expected to be in /usr/bin. You must
       change  this  if it is not there. Just set the first line of merge
       to your path to perl, or just run merge as an argument to the Perl
       interpreter. For the latter case, the command line would be:
       >    perl    merge   -m[NS,IE]   master-bookmarks.html   -s[NS,IE]
       slave-bookmarks.html

License

   merge  uses  the GPL. Please see the License.txt file that should have
   come with this package or: [3]http://www.gnu.org/copyleft/gpl.html for
   a copy of the license.

Feedback

   Feedback  should  be  sent  to  [4]buchmann@cs.unr.edu.  I  am  mostly
   interested  in  bugs/platform  issues,  but  any  improvements  or new
   features will be welcomed.

References

   1. http://sourceforge.net/
   2. http://merge.sourceforge.net/
   3. http://www.gnu.org/copyleft/gpl.html
   4. mailto:buchmann@cs.unr.edu
